<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "utenti";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

session_start();

// LOGIN
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username_login = trim($_POST['username_login']);
    $password_login = trim($_POST['password_login']);
    $login_messaggio = '';

    if (empty($username_login) || empty($password_login)) {
        $login_messaggio = "Compila tutti i campi.";
    } else {
        $stmt = $conn->prepare("SELECT password FROM utenti WHERE username = ?");
        $stmt->bind_param("s", $username_login);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && $res->num_rows > 0) {
            $row = $res->fetch_assoc();
            if (password_verify($password_login, $row['password'])) {
                $_SESSION['logged_in'] = true;
                $_SESSION['username'] = $username_login;
                $login_messaggio = "Login effettuato!";
                // Puoi fare un redirect se vuoi
                // header("Location: index.php"); exit;
            } else {
                $login_messaggio = "Password errata.";
            }
        } else {
            $login_messaggio = "Utente non trovato.";
        }
        $stmt->close();
    }
}

// CREATE (Registrazione)
$messaggio = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registrati'])) {
    $nome = trim($_POST['nome']);
    $cognome = trim($_POST['cognome']);
    $mail = trim($_POST['mail']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($nome) || empty($cognome) || empty($mail) || empty($username) || empty($password)) {
        $messaggio = "Compila tutti i campi.";
    } else {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO utenti (nome, cognome, mail, username, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nome, $cognome, $mail, $username, $password_hash);
        if ($stmt->execute()) {
            $messaggio = "Registrazione avvenuta con successo!";
        } else {
            $messaggio = "Errore nella registrazione: " . $conn->error;
        }
        $stmt->close();
    }
}

// DELETE
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM utenti WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $messaggio = "Utente eliminato con successo!";
    } else {
        $messaggio = "Errore nell'eliminazione: " . $conn->error;
    }
    $stmt->close();
}

// UPDATE (Modifica)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['modifica'])) {
    $id = intval($_POST['id']);
    $nome = trim($_POST['nome']);
    $cognome = trim($_POST['cognome']);
    $mail = trim($_POST['mail']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($nome) || empty($cognome) || empty($mail) || empty($username)) {
        $messaggio = "Compila tutti i campi.";
    } else {
        if (!empty($password)) {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE utenti SET nome=?, cognome=?, mail=?, username=?, password=? WHERE id=?");
            $stmt->bind_param("sssssi", $nome, $cognome, $mail, $username, $password_hash, $id);
        } else {
            $stmt = $conn->prepare("UPDATE utenti SET nome=?, cognome=?, mail=?, username=? WHERE id=?");
            $stmt->bind_param("ssssi", $nome, $cognome, $mail, $username, $id);
        }
        if ($stmt->execute()) {
            $messaggio = "Utente modificato con successo!";
        } else {
            $messaggio = "Errore nella modifica: " . $conn->error;
        }
        $stmt->close();
    }
}

// READ (Lista utenti)
$utenti = [];
$result = $conn->query("SELECT * FROM utenti ORDER BY id DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $utenti[] = $row;
    }
}

// Per la modifica: recupera dati utente
$utente_modifica = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM utenti WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows > 0) {
        $utente_modifica = $res->fetch_assoc();
    }
    $stmt->close();
}
?>

<!doctype html>
<html lang="it">

<head>
    <meta charset="utf-8">
    <title>Gestione Utenti</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-icons.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("includes/navbar.php"); ?>

    <!-- Bottone per aprire la modale login -->
    <div class="container mt-3">
        <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#loginModal">
            Login
        </button>
    </div>

    <!-- Modale Bootstrap per login -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="post" class="text-start">
            <div class="modal-header">
              <h5 class="modal-title" id="loginModalLabel">Login Utente</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <?php if (!empty($login_messaggio)): ?>
                    <div class="alert alert-info"><?php echo htmlspecialchars($login_messaggio); ?></div>
                <?php endif; ?>
                <div class="mb-3">
                    <label for="username_login" class="form-label">Username</label>
                    <input type="text" name="username_login" id="username_login" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="password_login" class="form-label">Password</label>
                    <input type="password" name="password_login" id="password_login" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" name="login" class="btn btn-primary">Login</button>
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <main>
        <section class="section-padding section-bg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-9 col-12 mx-auto">
                        <div class="custom-text-box text-center p-4 shadow rounded bg-white mb-4">
                            <h2 class="mb-2">Registrazione Utente</h2>
                            <p class="mb-4">Compila il modulo per creare un nuovo account.</p>
                            <?php if (!empty($messaggio) && !$utente_modifica): ?>
                                <div class="alert alert-info"><?php echo htmlspecialchars($messaggio); ?></div>
                            <?php endif; ?>
                            <form method="post" class="mb-3 text-start">
                                <div class="mb-3">
                                    <label for="nome" class="form-label">Nome</label>
                                    <input type="text" name="nome" id="nome" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="cognome" class="form-label">Cognome</label>
                                    <input type="text" name="cognome" id="cognome" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="mail" class="form-label">Email</label>
                                    <input type="email" name="mail" id="mail" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" name="username" id="username" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" name="password" id="password" class="form-control" required>
                                </div>
                                <button type="submit" name="registrati" class="custom-btn btn btn-primary w-100">Registrati</button>
                            </form>
                        </div>
                        <div class="custom-text-box p-4 shadow rounded bg-white">
                            <h3 class="mb-3">Lista Utenti</h3>
                            <div class="table-responsive">
                                <table class="table table-bordered align-middle">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nome</th>
                                            <th>Cognome</th>
                                            <th>Email</th>
                                            <th>Username</th>
                                            <th>Azioni</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($utenti as $utente): ?>
                                            <tr>
                                                <td><?php echo $utente['id']; ?></td>
                                                <td><?php echo htmlspecialchars($utente['nome']); ?></td>
                                                <td><?php echo htmlspecialchars($utente['cognome']); ?></td>
                                                <td><?php echo htmlspecialchars($utente['mail']); ?></td>
                                                <td><?php echo htmlspecialchars($utente['username']); ?></td>
                                                <td class="text-center d-flex gap-2 justify-content-center">
                                                    <a href="test2.php?edit=<?php echo $utente['id']; ?>" class="btn btn-sm btn-warning">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <a href="test2.php?delete=<?php echo $utente['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Sei sicuro di voler eliminare questo utente?');">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($utenti)): ?>
                                            <tr>
                                                <td colspan="6" class="text-center">Nessun utente registrato.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include("includes/footer.php"); ?>
    <script src="js/click-scroll.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <?php if ($utente_modifica): ?>
        <!-- Modale Bootstrap per modifica utente -->
        <div class="modal fade" id="modificaUtenteModal" tabindex="-1" aria-labelledby="modificaUtenteLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="post" class="text-start">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modificaUtenteLabel">Modifica Utente</h5>
                            <a href="test2.php" class="btn-close"></a>
                        </div>
                        <div class="modal-body">
                            <?php if (!empty($messaggio)): ?>
                                <div class="alert alert-info"><?php echo htmlspecialchars($messaggio); ?></div>
                            <?php endif; ?>
                            <input type="hidden" name="id" value="<?php echo $utente_modifica['id']; ?>">
                            <div class="mb-3">
                                <label for="nome_mod" class="form-label">Nome</label>
                                <input type="text" name="nome" id="nome_mod" class="form-control" required value="<?php echo htmlspecialchars($utente_modifica['nome']); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="cognome_mod" class="form-label">Cognome</label>
                                <input type="text" name="cognome" id="cognome_mod" class="form-control" required value="<?php echo htmlspecialchars($utente_modifica['cognome']); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="mail_mod" class="form-label">Email</label>
                                <input type="email" name="mail" id="mail_mod" class="form-control" required value="<?php echo htmlspecialchars($utente_modifica['mail']); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="username_mod" class="form-label">Username</label>
                                <input type="text" name="username" id="username_mod" class="form-control" required value="<?php echo htmlspecialchars($utente_modifica['username']); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="password_mod" class="form-label">Nuova Password (lascia vuoto per non cambiare)</label>
                                <input type="password" name="password" id="password_mod" class="form-control">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" name="modifica" class="btn btn-primary">Salva Modifiche</button>
                            <a href="test2.php" class="btn btn-secondary">Annulla</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script>
            var modificaModal = new bootstrap.Modal(document.getElementById('modificaUtenteModal'));
            modificaModal.show();
        </script>
    <?php endif; ?>
</body>

</html>