# Template

This repository contains a basic template for PHP projects to use as a starting point for exams or practice exercises.

## Requirements

- PHP >= 7.4
- MySQL/MariaDB (if required by the project)
- XAMPP or a compatible environment

## Installation

1. Clone or download this repository into your XAMPP `htdocs` folder:
   ```bash
   git clone <repo-url>
   ```
2. Start Apache and MySQL from the XAMPP control panel.
3. (Optional) Import the database if a .sql file is provided.

## Project Structure
1. index.php: Main entry point.
2. README.md: This file.
3. Other files and folders as needed for your project.

## Notes
1. Customize this template by adding your own features.
2. Refer to the PHP documentation for more information.

